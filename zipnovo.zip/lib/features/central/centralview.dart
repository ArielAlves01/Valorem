import 'package:flutter/material.dart';



class CentralView extends StatelessWidget {
  const CentralView({super.key});

  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
